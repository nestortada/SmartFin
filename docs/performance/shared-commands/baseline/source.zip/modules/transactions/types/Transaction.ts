import type { CurrencyCode, ISODateString } from '../../../shared/types';
import type { TransactionDateFields } from '../../../shared/utils/transactionDate';

export type TransactionType =
  | 'income'
  | 'expense'
  | 'internalTransfer'
  | 'creditCardPayment'
  | 'loanPayment'
  | 'investment'
  | 'refund'
  | 'manualAdjustment';

export type TransactionDirection = 'inflow' | 'outflow' | 'neutral';

export type TransactionStatus = 'posted' | 'pending' | 'cancelled';

export type TransactionPaymentMethod = 'debit' | 'credit';

export type Transaction = TransactionDateFields & {
  id: string;
  amount: number;
  currency: CurrencyCode;
  description: string;
  date: ISODateString;
  accountId: string;
  categoryId?: string;
  subcategoryId?: string;
  type: TransactionType;
  direction: TransactionDirection;
  status: TransactionStatus;
  targetAccountId?: string;
  merchantName?: string;
  paymentMethod?: TransactionPaymentMethod;
  creditCardHint?: string;
  dedupeKey?: string;
  notes?: string;
  createdAt: ISODateString;
  updatedAt: ISODateString;
};
