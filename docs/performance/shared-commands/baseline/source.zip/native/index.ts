export type NativeCapability = 'biometrics' | 'secure-storage';
export {
  RNSpeechRecognitionModule,
  useSpeechRecognitionEvent,
  type RNSpeechRecognitionErrorEvent,
  type RNSpeechRecognitionResultEvent,
} from './speechRecognition';
